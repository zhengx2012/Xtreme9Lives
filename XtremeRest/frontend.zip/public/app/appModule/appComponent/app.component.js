angular.module("appModule")
.component("appComponent", {
	templateUrl : "app/appModule/appComponent/app.component.html"
});
