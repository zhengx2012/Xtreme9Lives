angular.module('appModule')
.component("aboutComponent", {
	templateUrl : "app/appModule/aboutComponent/about.component.html",
	controller : function(){
		
		  var vm = this;

	},
	controllerAs : 'vm'
});