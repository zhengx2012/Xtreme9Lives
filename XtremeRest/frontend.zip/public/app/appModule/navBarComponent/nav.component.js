angular.module("appModule")
.component("navbar", {
	templateUrl : "app/appModule/navBarComponent/nav.component.html",
	controller : function(){
		var vm = this;
	},
	controllerAs: "vm"
});
